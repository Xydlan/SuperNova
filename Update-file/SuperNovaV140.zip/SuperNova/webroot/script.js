import Axeron from "/axeron.js";
import AxConstant from "/axConstant.js";
import Dialog from 'https://fahrez.one/dialog.js';

class Main {
  thisDataPath = `/sdcard/Android/data/${AxConstant.MODULE_PKG}`;
  shellPath = `${AxConstant.MODULE_PATH}/shell`;
  settingsSuperNovaDelete = "settings delete global supernova_package";
  settingsRenderDelete = "settings delete global render_ex_game"
  settingsSuperNovaGet = "settings get global supernova_package";
  settingsSuperNovaPut = "settings put global supernova_package $MODULE_PKG";
  settingsRenderGet = "settings get global render_ex_game"
  settingsRenderPut = "settings put global render_ex_game true"
  settingsCachesGet = `[ -f "${this.thisDataPath}/cache" ] && echo "true" || echo "false"`
  linkTele = `am start -a android.intent.action.VIEW -d "https://t.me/XarenaRenata"`;
  linkFitur = "./index.html";
  linkMenu = "./addon.html";
  switchSuperNova;
  switchCaches;
  switchRender;
  textId;
  textAppImpacted;
  stringImpactedIs;
  btnOptimize;
  btnTeleCH;
  btnMenu;
  btnFitur;
  currentImpactSetting = "";
  currentCachesSetting = false;
  appName = "";

  constructor() {
    console.log("from constructor");
    this.initComponent();
    this.fetchSettings();
    this.cekMaintenance();
    const dialog = new Dialog();
    dialog.setTitle('Can\'t use this V-Mods');
    dialog.setSubtitle('You need to update Vortex Core');
    dialog.setCancelable(false);
    if (AxConstant.AX_VCODE < 241201900) {
      dialog.show();
    }

    //setTimeout(() => {
      //dialog.hide();
    //}, 5000);
  }

  async fetchSettings() {
    try {
      const { stdout: getSuperNovaSettings } = await Axeron.exec(
          this.settingsSuperNovaGet
        );
      this.currentSuperNovaSetting = getSuperNovaSettings;
      console.log(this.currentSuperNovaSetting)
      const { stdout: getRenderSettings } = await Axeron.exec(
          this.settingsRenderGet
        );
      this.currentRenderSetting = getRenderSettings;
      
      if (this.currentRenderSetting) {
        console.log(this.currentRenderSetting)
      } else {
        console.log(`Error Check render`)
      }
      const { stdout: nameAppImpacted } = await Axeron.exec(
          "pkglist -L " + getSuperNovaSettings
        );
        
      ({ stdout: this.currentCachesSetting } = await Axeron.exec(this.settingsCachesGet));
        
      console.log(this.currentCachesSetting)
      
      this.textAppImpacted.innerHTML = `${this.stringImpactedIs} <span style="color: #ff5503">${nameAppImpacted}</span>`;
      if (this.currentSuperNovaSetting == "null") {
        this.textAppImpacted.innerHTML = `${this.stringImpactedIs} <span style="color: #ff5503">Deleted</span>`;
      }
      const { stdout: nameApp } = await Axeron.exec(
        "pkglist -L " + AxConstant.MODULE_PKG
      );
      this.appName = nameApp;

      this.updateSwitchState();
    } catch (error) {
      Axeron.toast("Error", error.toString());
    }
  }

  cekMaintenance() {
    const savePath = '/sdcard/VortexModules/SuperNovaUpdate.zip';
    const downloader = new Axeron.StormDownload("apk_download");
    downloader.onStart(() => {
      console.log("Download dimulai...");
    });
    
    downloader.onProgress((progress) => {
      console.log("Progress:", progress + "%");
    });
    
    downloader.onSuccess((result) => {
      console.log("Download berhasil:", result);
      Axeron.toast("Sukses", "Download selesai!");
    });
    
    downloader.onFailure((error) => {
      console.error("Download gagal:", error);
      Axeron.toast("Gagal", "Download error!");
    });
    
    fetch('https://xydlan.github.io/SuperNova/data/superUpdate.json')
    .then(response => response.json())
    .then(data => {
      if (data.Visibility === "VISIBLE") {
        document.getElementById('updateBox').style.display = 'block';
        document.getElementById('transparent-display').style.position = 'fixed';
        document.getElementById('title').innerText = data.Title;
        document.getElementById('alert').innerText = data.Title;
        document.getElementById('description').innerText = data.Description;
        document.getElementById('version').innerText = data.Version;
        document.getElementById('mainButton').innerText = data.MainTextButton;
        document.getElementById('mainButton').addEventListener('click', () => {
          downloader.download(data.DownloadLink, savePath);
        });
        const transparent = document.getElementById('transparent-display');
        const display = document.getElementById('updateBox');
        const cancelButton = document.getElementById('cancelButton');
        cancelButton.innerText = data.CancelButtonText || "Cancel";
        cancelButton.style.display = data.Cancelable === "true" ? "inline-block" : "none";
        cancelButton.addEventListener("click", () => {
          display.style.display = 'none';
          transparent.style.position = 'relative';
        });
        Axeron.toast('Maintenance', 'Update Versi 1.3.1', 1500);
      } else {
        Axeron.toast('Versi Sudah Paling Baru', '1.2.1', 1500);
      }
    });
  }
// Fungsi untuk mengatur on/off
  updateSwitchState() {
    if (this.currentSuperNovaSetting === AxConstant.MODULE_PKG) {
      if (this.switchSuperNova) {
        this.switchSuperNova.checked = true;
      }
    }
    
    if (this.switchCaches) {
        this.switchCaches.checked = this.currentCachesSetting === "true";
    }
    
    if (this.currentRenderSetting === "true") {
      if (this.switchRender) {
          this.switchRender.checked = true;
          console.log(this.switchRender.checked)
      }
    }
  }

  initComponent() {
    this.switchSuperNova = document.getElementById("toggle_impact");
    this.switchCaches = document.getElementById("toggle_caches");
    this.switchRender = document.getElementById("toggle_render");
    this.textId = document.getElementById("id");
    this.textAppImpacted = document.getElementById('app_impacted');
    this.btnOptimize = document.getElementById("btn_optimize");
    this.btnTeleCH = document.getElementById("telegram_link");
    this.btnFitur = document.getElementById("fitur_link");
    this.btnMenu = document.getElementById("menu_link");
    this.textId.textContent = AxConstant.AX_ID;
    this.stringImpactedIs = this.textAppImpacted.textContent;
    
    const textAppName = document.getElementById('app_name');
    textAppName.textContent = AxConstant.MODULE_PKG_NAME;
    
    const textAppPkg = document.getElementById('app_pkg');
    textAppPkg.textContent = AxConstant.MODULE_PKG;
    
    const textAppVName = document.getElementById('app_vname');
    textAppVName.textContent = 'V ' + AxConstant.MODULE_PKG_VNAME;
    
    const textAppVCode = document.getElementById('app_vcode');
    textAppVCode.textContent = AxConstant.MODULE_PKG_VCODE;
    
    const appIcon = document.getElementById('app_icon');
    
    const img = document.createElement('img');
    img.src = AxConstant.getPackageIcon(AxConstant.MODULE_PKG);
    img.alt = 'Gambar yang dimuat';
    
    appIcon.appendChild(img);

    this.initListeners();
  }
  
  async putImpact() {
    const { stdout: getSuperNovaSettings } = await Axeron.exec(
          this.settingsSuperNovaPut + " && " + this.settingsSuperNovaGet
        );
    this.textAppImpacted.innerHTML = `${this.stringImpactedIs} <span style="color: #ff5503">${this.appName}</span>`;
  }
  
  async putRender() {
    const { stdout: getRenderSettings } = await Axeron.exec(
          this.settingsRenderPut + " && " + this.settingsRenderGet
    );
  }
  async execImpact(isDisable) {
    const execImpact = `sh ${this.shellPath}/vex.sh ${isDisable}`
    const { stdout: getImpactPutSettings } = await Axeron.exec(
      execImpact
    );
    if (isDisable) {
      Axeron.toast("Activated", getImpactPutSettings , 1500);
    } else {
      Axeron.toast("Disabled", getImpactPutSettings , 1500);
      this.textAppImpacted.innerHTML = `${this.stringImpactedIs} <span style="color: #ff5503">Deleted</span>`;
    }
  }
  async execCaches(isDisable) {
    const execCaches = `sh ${this.shellPath}/caches.sh ${isDisable} ${AxConstant.MODULE_PKG}`;
    const { stdout: getCachesSettings } = await Axeron.exec(
          execCaches
        );
    if (isDisable) {
      Axeron.toast("Activated", getCachesSettings, 1500);
    } else {
      Axeron.toast("Disabled", getCachesSettings, 1500);
    }
  }
  async execRender(isDisable) {
    const execRender = `sh ${this.shellPath}/render.sh ${isDisable}`;
    const { stdout: getRendererSettings } = await Axeron.exec(
          execRender
        );
    if (isDisable) {
      Axeron.toast("Activated", getRendererSettings, 1500);
    } else {
      Axeron.toast("Disabled", getRendererSettings, 1500);
    }
  }
  
  
  initListeners() {
    this.switchSuperNova.addEventListener("change", () => {
      if (this.switchSuperNova.checked) {
        console.log("Active");
        this.putImpact();
        this.execImpact(true);
      } else {
        console.log("Non-Active");
        this.execImpact(false);
        Axeron.exec(this.settingsSuperNovaDelete);
      }
    });

    this.switchCaches.addEventListener("change", () => {
      if (this.switchCaches.checked) {
        console.log("Active");
        this.execCaches(true);
      } else {
        console.log("Non-Active");
        this.execCaches(false);
      }
    });
    
    this.switchRender.addEventListener("change", () => {
      if (this.switchRender.checked) {
        console.log("Active");
        this.putRender();
        this.execRender(true);
        Axeron.exec(
          "setprop debug.hwui.renderer skiavk"
        );
      } else {
        console.log("Non-Active");
        this.execRender(false);
        Axeron.exec(this.settingsRenderDelete);
      }
    });

    this.btnOptimize.addEventListener("click", () => {
      const vexExec = `sh ${this.shellPath}/optimize.sh`;
      console.log("Optimized");
      Axeron.exec(vexExec);
      Axeron.optimizeApp();
    });
    this.btnTeleCH.addEventListener("click", () => {
      console.log(`Masuk ke dalam ${this.linkTele}`);
      Axeron.exec(this.linkTele);
    });
    this.btnFitur.addEventListener("click", () => {
      console.log(`masuk ke dalam ${this.linkFitur}`);
      window.open(this.linkFitur, "_blank");
    });
    this.btnMenu.addEventListener("click", () => {
      console.log(`masuk ke dalam ${this.linkMenu}`);
      window.open(this.linkMenu, "_blank");
    });
  }
  
}

export default new Main();
