$AXFUN

folderCache="/sdcard/Android/data/${2}/cache"

if [ "$1" = "true" ]; then
  [ -d "$folderCache" ]; rm -r "$folderCache"
  
  echo "Locked" > "$folderCache"
  echo "Caches adjusted for $(pkglist -L $MODULE_PKG)"
  am memory-factor set CRITICAL
  cmd display ab-logging-disable
  cmd display dwb-logging-disable
  cmd display dmd-logging-disable
  cmd looper_stats disable
else
  if [ -f "$folderCache" ]; then
    rm -r "$folderCache"
    echo "Caching features removed"
    cmd display ab-logging-enable
    cmd display dwb-logging-enable
    cmd display dmd-logging-enable
    cmd looper_stats reset
  else
    echo "Failed to remove"
  fi
fi
exit 0